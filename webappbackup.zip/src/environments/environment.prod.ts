export const environment = {
  production: true,
  apiEndpoint:"http://rcmquerylive.cms.com/rcmquery/api/"
  //apiEndpoint: "http://172.19.8.26/rcmquery/api/"
  //apiEndpoint: "http://cmsliveuat.cms.com/rcmquery/api/"
};
