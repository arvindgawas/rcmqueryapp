
export class customer
{
    public ID: number;
    public Name: string;
}

export class User
{
    public ID: string;
    public UserName: string;
}

export class ddlisttracker
{
    customerlst : customer[];
    Userlst   : User[];
}
