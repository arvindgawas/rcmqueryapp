export class LoginModel
{
    public UserId: string = "";
    public Password: string = "";
    public Confirmpassword : string;
}