export class report
{
    public fromdate: Date;
    public todate: Date;
    public user: string ;
    public region : string;
    public location: string;
    public hublocation : string;
    public customer : string;
    public customertype : string;
    public cdpncm : string;
    public issuetype : string;
    public sla : string;
}


