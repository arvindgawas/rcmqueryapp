export class EmpExamMap
{
    public EmployeeId: string;
    public ExamID: Number;
    public CorrectAns: Number;
    public PerScore: Number;
    public Status: string;
}

