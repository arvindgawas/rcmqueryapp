export class rcmLoginModel
{
    public Username: string = "";
    public Password: string = "";
}