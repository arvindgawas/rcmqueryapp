
export class ticketlogin
{
    public UserId : string = "";
    public Password: string = "";
    public userrole: string ="";
}


