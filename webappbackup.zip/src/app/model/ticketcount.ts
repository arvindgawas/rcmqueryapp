export class ticketcount
{
    public userid: string;
    public date : Date;
    public bank: string;
    public opencount: number ;
    public acceptcount : number;
    public duplicatecount: number;
    public rejectcount : number;
    public pendingcount : number;
    public closecount : number;
    public totalcount : number;
}


