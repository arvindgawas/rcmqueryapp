export class rcm
{
    public customer: string;
    public pickupcode: string ;
    public clientcode: string;
}

