export class rcmdetail
{
    public crn: string;
    public clientname: string ;
    public cdpncm: string;
    public area: string;
    public region: string;
    public location: string;
    public hublocation: string;
    public customertype: string;
    public hierarchycode: string;
    public pickupcode :string;
    public clientcode :string;
    public Company :string;
    public customer :string;
}



