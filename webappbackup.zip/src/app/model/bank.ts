export class bank
{
    public bankname: string;
    public bankdomain: string;
    
}


