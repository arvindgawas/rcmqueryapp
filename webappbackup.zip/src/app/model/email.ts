export class email
{
    public ticketno: string;
    public toemailid: string;
    public ccemailid: string ;
    public emailsubject : string;
    public emailbody: string;
    public emailattachment: string;
    public emailsubject1 : string;
    public sentdate : Date;
    public filepath : string;
    public location : boolean;
}


